<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<center>
<p style="font-size:50px;">404 NOT FOUND</p> 
</center>
    
<?php $this->need('footer.php'); ?>