
    </div>
<div class="footer">
 &copy; 2017 <a href="<?php $this->options->siteUrl(); ?>" real="nofollow"><?php $this->options->title() ?></a> . Powered by <a rel="nofollow" target="_blank" href="https://typecho.me/954.html">typecho</a> . Theme by <a rel="nofollow" href="http://xema.ink">Xema</a> 
</div>

</body>
</html>